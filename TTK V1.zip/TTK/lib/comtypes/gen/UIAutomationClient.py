from comtypes.gen import _944DE083_8FB8_45CF_BCB7_C477ACB2F897_0_1_0
globals().update(_944DE083_8FB8_45CF_BCB7_C477ACB2F897_0_1_0.__dict__)
__name__ = 'comtypes.gen.UIAutomationClient'